﻿// 10 page 내용입니다.

#include <stdio.h> 

int main()
{
	printf("hello\n"); // ok
	std::printf("hello\n"); // ??
}
