﻿// 6_함수5
// C++ 함수 특징 5. 함수 삭제. C++11에서 추가된 기능
// 35 page

int gcd(int a, int b)
{
	return 0;
}
int main()
{
	gcd(1, 2);
	gcd(2.3, 3.2);
}
