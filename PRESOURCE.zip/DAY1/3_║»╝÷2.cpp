﻿#include <iostream>

struct Point
{
	int x, y;
};
int main()
{
	// 20page - 중요한 변화.!
	int n = 10;
	int x[3] = { 1,2,3 };
	Point p1 = { 1,2 };
}



