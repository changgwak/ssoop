﻿// 4_함수6. 후위 반환 타입

int square(int a)
{
	return a * a;
}
int main()
{
	square(3);
}
