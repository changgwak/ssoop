﻿// 10_캐스팅1.cpp    48 page
#include <iostream>

int main()
{
	int n = 3;

	double* p = &n; // ??

}
