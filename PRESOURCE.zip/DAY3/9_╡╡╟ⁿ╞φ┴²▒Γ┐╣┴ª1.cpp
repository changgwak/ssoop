﻿// 예제1     152 page
#include <iostream>
#include <vector>

int main()
{
}



