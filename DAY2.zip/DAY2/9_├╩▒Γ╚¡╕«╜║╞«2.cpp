#include <string>

int main()
{
	// #1. �ʱ�ȭ vs ����
	int a = 3;
	int b;
	b = 3;



	// #2. 
	std::string s1{ "hello" };

	std::string s2;
	s2 = "hello";
}