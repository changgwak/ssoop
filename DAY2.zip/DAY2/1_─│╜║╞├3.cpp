﻿#include <iostream>

// reinterpret_cast 
// 1. 서로 다른 타입의 주소 변환
// 2. 정수 <=> 포인터 변환

int main()
{
	double d = 3.4;
	
	int* p1 = (int*)&d;

	int* p2 = static_cast<int*>(&d);
	int* p3 = reinterpret_cast<int*>(&d);

	int* p4 = 1000;
}

