﻿#include <iostream>

// member field initialization
class Point
{
	int x, y;
public:
	Point() {}
	Point(int a) : y{ a } {}
};


int main()
{

}




