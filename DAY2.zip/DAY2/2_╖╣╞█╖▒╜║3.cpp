﻿// 1_레퍼런스3. 63 page
struct Data
{
	int buff[1024];
};

void foo(? n)
{
}
int main()
{
	int x = 100;

	// foo 는 전달된 인자의 x 를 절대 변경하면 안된다.
	foo(x);
}
