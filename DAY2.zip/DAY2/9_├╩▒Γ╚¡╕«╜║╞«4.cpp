#include <string>

class Person1
{
	std::string name;
	int age;
public:
	Person1(const std::string& n, int a) 
	{
		name = n;
		age = a;
	}
};

Person1 p1{ "kim", 20 };

class Person2
{
	std::string name;
	int age;
public:
	Person2(const std::string& n, int a) : name{n}, age{a}
	{
	}
};

Person2 p2{ "kim", 20 };