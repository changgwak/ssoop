// 5_������1.cpp - 80 page
#include <iostream>
#include <string>

class Person
{
public:
	std::string name;
	int  age;
};
int main()
{
	Person p = { "kim", 28 };

}



