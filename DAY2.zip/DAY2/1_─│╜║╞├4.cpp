﻿// const_cast 
// => 객체의 상수성 제거

int main()
{
	int n = 10;

	const int* p1 = &n;


	int* p2 = p1; // ?
}
