#include <iostream>

// friend 79page ~

class Bike
{
	int gear = 0;
public:
	void setGear(int n) { gear = n; }
};

void fixBike(Bike& b)
{
	b.gear = 10;
}

int main()
{
	Bike b;
	fixBike(b);
}