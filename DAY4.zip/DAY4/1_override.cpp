﻿// override  145 page ~

class Shape
{
public:
	virtual void draw() {};
};
class Rect : public Shape
{
public:
	virtual void draw()  {};
};
int main()
{

}
